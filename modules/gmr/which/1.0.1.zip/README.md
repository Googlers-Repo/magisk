# which

A binariy that excludes root related binaries

> Warning
> This module can break system functionality!

## Hidden binaries

- su 
- tsu
- magisk
- magiskboot
- magiskpolicy
- supolicy
- resetprop
- ksu
- ksud
- magiskinit