# systemless hosts KernelSU module
Required module to use applications such as AdAway on KernelSU
- [Download](https://github.com/symbuzzer/systemless-hosts-KernelSU-module/releases/latest/download/systemless-hosts-KernelSU-module.zip)
- [Changelog](https://github.com/symbuzzer/systemless-hosts-KernelSU-module/blob/main/CHANGELOG.md)

## Thanks:
- Original code and idea: [HuskyDG](https://github.com/HuskyDG)
- For his support: [tiann](https://github.com/tiann)
