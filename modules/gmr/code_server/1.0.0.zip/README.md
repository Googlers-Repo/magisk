[nodejs]: https://github.com/Magisk-Modules-Alt-Repo/node
[mkshrc]: https://github.com/Magisk-Modules-Alt-Repo/mkshrc
[foxm]: https://github.com/Fox2Code/FoxMagiskModuleManager

# Code Server for Magisk

VS Code in the browser

## Requirements

- [Systemless Mkshrc][mkshrc]
- [Node.js][nodejs]

## Installation

Magisk or [Fox's Magisk Module Manager][foxm]

## Config location

```
/data/chuser/<USER>/home/.config
```