export PATH="$PATH:/system/usr/share/code-server/bin"
